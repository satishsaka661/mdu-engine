# mdu_engine/version.py

ENGINE_VERSION = "1.1.0"
RULESET_VERSION = "1.0.0"
# update when decision rules change
